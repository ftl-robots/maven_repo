#include "HAL/HAL.h"
#include "HAL/handles/HandlesInternal.h"
#include "com_ftlrobots_ftlbridge_jni_RegisterCallbacksJni.h"

#include <iostream>

static bool sInitialized = false;

JNIEXPORT void JNICALL Java_com_ftlrobots_ftlbridge_jni_RegisterCallbacksJni_resetWpiHal (JNIEnv *, jclass) {
    if (!sInitialized) {
        sInitialized = true;

        std::cout << "Initializing Simulator" << std::endl;

        if (!HAL_Initialize(0, 0)) {
            std::cerr << "Could not initialize!" << std::endl;
        }
    }

    hal::HandleBase::ResetGlobalHandles();
}