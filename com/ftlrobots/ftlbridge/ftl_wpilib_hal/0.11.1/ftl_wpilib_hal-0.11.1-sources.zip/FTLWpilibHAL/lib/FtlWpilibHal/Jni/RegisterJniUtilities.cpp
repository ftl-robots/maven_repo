#include "FtlWpilibHal/Jni/RegisterJniUtilities.h"

#include "wpi/jni_util.h"
#include <iostream>

using namespace wpi::java;

JavaVM* FTLWpilibHAL::gJvm = NULL;

namespace FTLWpilibHAL {
    void SetGlobalEnvironment(JNIEnv *env) {
        env->GetJavaVM(&gJvm);
    }

    void SetCallbackContainerInfo(JNIEnv* env, jclass clz, const std::string& functionName, FTLWpilibHAL::CallbackHelperContainer& outContainer) {
        outContainer.mClazz = clz;
        outContainer.mMethodId = env->GetStaticMethodID(clz, functionName.c_str(), "(Ljava/lang/string;ILcom/ftlrobots/ftlbridge/jni/HallCallbackValue;)V");

        if (outContainer.mMethodId == NULL) {
            std::cerr << "Failed to find method reference for function " << functionName << std::endl;
        }
    }

    jobject ConvertHalValue(JNIEnv* env, const struct HAL_Value* value) {
        static JClass theClazz = JClass(env, "com/ftlrobots/ftlbridge/jni/HalCallbackValue");
        static jmethodID constructor = 
                    env->GetMethodID(theClazz, "<init>", "(IZIJD)V");
        
        if (constructor == NULL) {
            std::cerr << "HalCallbackValue not set up correctly!" << std::endl;
            return NULL;
        }

        return env->NewObject(theClazz, constructor,
            static_cast<int>(value->type),
            value->data.v_boolean,
            value->data.v_enum,
            value->data.v_int,
            value->data.v_long,
            value->data.v_double);
    }

    void CallJavaCallback(const CallbackHelperContainer& callbackHelper, const char* name, void* param, const struct HAL_Value* value) {
        JavaVMAttachArgs args = {JNI_VERSION_1_2, 0, 0};
        JNIEnv* env;
        gJvm->AttachCurrentThread(reinterpret_cast<void**>(&env), &args);

        if (env == NULL || callbackHelper.mClazz == NULL || callbackHelper.mMethodId == NULL) {
            std::cerr << "JNI Components not set up!" << std::endl;
            return;
        }

        int port = *(reinterpret_cast<int*>(param));
        jstring nameString = MakeJString(env, name);
        jobject halValue = ConvertHalValue(env, value);

        env->CallStaticVoidMethod(callbackHelper.mClazz, callbackHelper.mMethodId, nameString, port, halValue);

        if (env->ExceptionCheck()) {
            env->ExceptionDescribe();
        }
    }
}